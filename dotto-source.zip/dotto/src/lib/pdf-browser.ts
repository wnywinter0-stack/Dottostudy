import { MAX_PDF_PAGES, splitPage } from './document-rules';
// Browser-only dynamic imports keep PDF rendering and OCR out of SSR.
export async function extractPdf(file: Blob, progress: (page: number, total: number) => void) {
  const pdfjs = await import('pdfjs-dist');
  const worker = await import('pdfjs-dist/build/pdf.worker.min.mjs?url');
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const task = pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) });
  const pdf = await task.promise;
  if (pdf.numPages > MAX_PDF_PAGES) { await task.destroy(); throw new Error('docs.tooManyPages'); }
  let ocr: Awaited<ReturnType<typeof import('tesseract.js')['createWorker']>> | undefined;
  const chunks: { page: number; content: string }[] = [];
  const failed: number[] = [];
  const pages = pdf.numPages;
  try {
    for (let p = 1; p <= pages; p++) {
      const page = await pdf.getPage(p);
      const text = await page.getTextContent();
      let content = text.items.map(item => 'str' in item ? item.str : '').join(' ').trim();
      if (content.length < 30) {
        try {
          if (!ocr) { const { createWorker } = await import('tesseract.js'); ocr = await createWorker(['eng', 'fra', 'ara']); }
          const viewport = page.getViewport({ scale: Math.min(2, 1800 / page.getViewport({ scale: 1 }).width) });
          const canvas = document.createElement('canvas'); canvas.width = viewport.width; canvas.height = viewport.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) throw new Error('Canvas unavailable');
          await page.render({ canvasContext: ctx, canvas, viewport }).promise;
          const result = await ocr.recognize(canvas);
          content = result.data.confidence >= 35 ? result.data.text.trim() : '';
          canvas.width = 0; canvas.height = 0;
        } catch { content = ''; }
      }
      if (content.length < 10) failed.push(p); else chunks.push(...splitPage(content, p));
      progress(p, pages); page.cleanup();
    }
    return { chunks, pages, failed };
  } finally { await ocr?.terminate(); await task.destroy(); }
}
