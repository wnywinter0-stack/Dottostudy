import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { requireSupabaseAuth } from '@/integrations/supabase/auth-middleware';
import { MAX_PDF_BYTES, MAX_PDF_PAGES } from './document-rules';

export const finishDocument = createServerFn({ method: 'POST' }).middleware([requireSupabaseAuth]).inputValidator(z.object({
  id: z.string().uuid(), pages: z.number().int().min(1).max(MAX_PDF_PAGES), failed: z.array(z.number().int().positive()).max(MAX_PDF_PAGES),
  chunks: z.array(z.object({ page: z.number().int().positive().max(MAX_PDF_PAGES), content: z.string().min(1).max(4500) })).max(3000),
})).handler(async ({ data, context }) => {
  const db = context.supabase;
  const { data: doc, error } = await db.from('documents').select('*').eq('id', data.id).single();
  if (error || !doc) throw new Error('docs.unavailable');
  const { data: file, error: fileError } = await db.storage.from('student-documents').download(doc.storage_path);
  if (fileError || !file || file.size > MAX_PDF_BYTES || !(await file.slice(0, 5).text()).startsWith('%PDF-')) throw new Error('docs.invalid');
  if (data.chunks.some(c => c.page > data.pages)) throw new Error('docs.invalid');
  const removed = await db.from('document_chunks').delete().eq('document_id', doc.id);
  if (removed.error) throw removed.error;
  for (let i = 0; i < data.chunks.length; i += 100) {
    const saved = await db.from('document_chunks').insert(data.chunks.slice(i, i + 100).map((c, j) => ({ ...c, document_id: doc.id, ordinal: i + j })));
    if (saved.error) throw saved.error;
  }
  const saved = await db.from('documents').update({ page_count: data.pages, status: !data.chunks.length ? 'failed' : data.failed.length ? 'partial' : 'ready', processing_error: data.failed.length ? data.failed.join(', ') : null }).eq('id', doc.id);
  if (saved.error) throw saved.error;
  return { ok: true };
});
