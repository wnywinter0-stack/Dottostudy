export const MAX_PDF_BYTES = 20 * 1024 * 1024;
export const MAX_PDF_PAGES = 300;
export function validPdf(name: string, size: number, header: string) {
  return /\.pdf$/i.test(name) && size > 0 && size <= MAX_PDF_BYTES && header.startsWith('%PDF-');
}
export function splitPage(content: string, page: number) {
  const chunks: { page: number; content: string }[] = [];
  for (let i = 0; i < content.length; i += 4000) chunks.push({ page, content: content.slice(i, i + 4500) });
  return chunks;
}
export function pageRequested(text: string) {
  const match = text.match(/(?:page|pages|p\.|صفحة|الصفحة)\s*(\d+)/i);
  return match ? Number(match[1]) : null;
}
