import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { DICTS, type Lang, type TKey } from "./i18n-dict";
import { supabase } from "@/integrations/supabase/client";

type Ctx = { lang: Lang; dir: "ltr" | "rtl"; t: (k: TKey) => string; setLang: (l: Lang) => void };
const I18nCtx = createContext<Ctx | null>(null);
const KEY = "dotto-lang";

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");
  useEffect(() => {
    const saved = localStorage.getItem(KEY) as Lang | null;
    if (saved && saved in DICTS) setLangState(saved);
  }, []);
  const dir = lang === "ar" ? "rtl" : "ltr";
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);
  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    localStorage.setItem(KEY, l);
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) supabase.from("profiles").update({ language: l }).eq("id", data.user.id).then(() => {});
    });
  }, []);
  const t = useCallback((k: TKey) => DICTS[lang][k] ?? DICTS.en[k] ?? k, [lang]);
  return <I18nCtx.Provider value={{ lang, dir, t, setLang }}>{children}</I18nCtx.Provider>;
}

export function useI18n() {
  const c = useContext(I18nCtx);
  if (!c) throw new Error("useI18n outside provider");
  return c;
}
