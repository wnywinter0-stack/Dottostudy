export type LessonLike = { completed: boolean; plan_id: string };
export type PlanLike = { id: string; subject_id: string | null };

export function pct(done: number, total: number) {
  return total === 0 ? 0 : Math.round((done / total) * 100);
}

export function planProgress(planId: string, lessons: LessonLike[]) {
  const ls = lessons.filter((l) => l.plan_id === planId);
  return pct(ls.filter((l) => l.completed).length, ls.length);
}

/** Overall and per-subject progress are weighted by lesson count. */
export function subjectProgress(plans: PlanLike[], lessons: LessonLike[]) {
  const bySubject = new Map<string | null, { done: number; total: number }>();
  const planSubject = new Map(plans.map((p) => [p.id, p.subject_id]));
  for (const l of lessons) {
    if (!planSubject.has(l.plan_id)) continue;
    const s = planSubject.get(l.plan_id) ?? null;
    const e = bySubject.get(s) ?? { done: 0, total: 0 };
    e.total++;
    if (l.completed) e.done++;
    bySubject.set(s, e);
  }
  const overall = pct(lessons.filter((l) => l.completed && planSubject.has(l.plan_id)).length,
    lessons.filter((l) => planSubject.has(l.plan_id)).length);
  return { overall, bySubject };
}

export function daysUntil(date: string | null, now = new Date()) {
  if (!date) return null;
  const target = new Date(date + "T00:00:00");
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.max(0, Math.round((target.getTime() - today.getTime()) / 86400000));
}

export function youtubeParse(url: string): { kind: "video" | "playlist" | "channel"; id: string | null } | null {
  try {
    const u = new URL(url.trim());
    const host = u.hostname.replace(/^www\.|^m\./, "");
    if (host === "youtu.be") return { kind: "video", id: u.pathname.slice(1) || null };
    if (host !== "youtube.com" && host !== "youtube-nocookie.com") return null;
    if (u.pathname === "/watch" && u.searchParams.get("v")) return { kind: "video", id: u.searchParams.get("v") };
    if (u.pathname.startsWith("/shorts/") || u.pathname.startsWith("/embed/") || u.pathname.startsWith("/live/"))
      return { kind: "video", id: u.pathname.split("/")[2] || null };
    if (u.pathname === "/playlist" && u.searchParams.get("list")) return { kind: "playlist", id: u.searchParams.get("list") };
    if (u.pathname.startsWith("/@") || u.pathname.startsWith("/channel/") || u.pathname.startsWith("/c/"))
      return { kind: "channel", id: null };
    return null;
  } catch {
    return null;
  }
}

export function fmtDuration(sec: number) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}
