import { describe, expect, it } from "vitest";
import { daysUntil, planProgress, subjectProgress, youtubeParse } from "@/lib/progress";

describe("progress", () => {
  const lessons = [
    { plan_id: "a", completed: true }, { plan_id: "a", completed: false },
    { plan_id: "b", completed: true }, { plan_id: "b", completed: true },
  ];
  it("plan percentage counts completed lessons", () => {
    expect(planProgress("a", lessons)).toBe(50);
    expect(planProgress("b", lessons)).toBe(100);
    expect(planProgress("c", lessons)).toBe(0);
  });
  it("overall progress is weighted by lessons", () => {
    const r = subjectProgress([{ id: "a", subject_id: "math" }, { id: "b", subject_id: "bio" }], lessons);
    expect(r.overall).toBe(75);
    expect(r.bySubject.get("math")).toEqual({ done: 1, total: 2 });
  });
  it("counts days to the exam", () => {
    expect(daysUntil("2027-06-01", new Date(2027, 4, 30))).toBe(2);
  });
  it("parses youtube links", () => {
    expect(youtubeParse("https://youtu.be/abc123")).toEqual({ kind: "video", id: "abc123" });
    expect(youtubeParse("https://www.youtube.com/watch?v=xyz")?.id).toBe("xyz");
    expect(youtubeParse("https://example.com")).toBeNull();
  });
});
