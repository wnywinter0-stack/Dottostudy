import { describe, expect, it } from 'vitest';
import { MAX_PDF_BYTES, MAX_PDF_PAGES, validPdf, splitPage, pageRequested } from '@/lib/document-rules';
describe('Private PDF validation and retrieval',()=>{
  it('accepts PDF signatures and rejects disguised non-PDF files',()=>{expect(validPdf('notes.pdf',100,'%PDF-1.7')).toBe(true);expect(validPdf('notes.pdf',100,'not a PDF')).toBe(false);expect(validPdf('notes.exe',100,'%PDF-1.7')).toBe(false);});
  it('enforces the configured file size limit',()=>{expect(MAX_PDF_BYTES).toBe(20971520);expect(validPdf('notes.pdf',MAX_PDF_BYTES+1,'%PDF-')).toBe(false);});
  it('keeps large documents page tagged and bounded for retrieval',()=>{const chunks=splitPage('a'.repeat(10000),17);expect(chunks.length).toBe(3);expect(chunks.every(c=>c.page===17&&c.content.length<=4500)).toBe(true);expect(MAX_PDF_PAGES).toBe(300);});
  it('targets paragraphs from an explicitly requested page',()=>{expect(pageRequested('Explain page 42')).toBe(42);expect(pageRequested('Explain الصفحة 12')).toBe(12);expect(pageRequested('Summarize')).toBe(null);});
});