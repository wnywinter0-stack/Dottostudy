import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { type Row, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";

export type NoteEditorHandle = { insert: (text: string) => void };

/** Autosaves 700ms after the student stops typing. */
export const NoteEditor = forwardRef<NoteEditorHandle, { note: Row<"notes">; onTimestampClick?: (sec: number) => void }>(
  function NoteEditor({ note, onTimestampClick }, ref) {
    const { t } = useI18n();
    const save = useUpsert("notes");
    const [title, setTitle] = useState(note.title);
    const [content, setContent] = useState(note.content);
    const [state, setState] = useState<"idle" | "saving" | "saved">("idle");
    const area = useRef<HTMLTextAreaElement>(null);
    const first = useRef(true);
    useEffect(() => { setTitle(note.title); setContent(note.content); first.current = true; }, [note.id]);
    useEffect(() => {
      if (first.current) { first.current = false; return; }
      setState("saving");
      const id = setTimeout(async () => {
        await save.mutateAsync({ id: note.id, title: title || "Untitled note", content });
        setState("saved");
      }, 700);
      return () => clearTimeout(id);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [title, content]);
    useImperativeHandle(ref, () => ({
      insert(text: string) {
        const el = area.current; const pos = el?.selectionStart ?? content.length;
        setContent(content.slice(0, pos) + text + content.slice(pos));
        setTimeout(() => el?.focus(), 0);
      },
    }));
    const stamps = [...content.matchAll(/\[(\d{1,2}):(\d{2})(?::(\d{2}))?\]/g)];
    return (
      <div className="flex h-full flex-col">
        <div className="flex items-center gap-3">
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="min-w-0 flex-1 bg-transparent font-display text-2xl outline-none" />
          <span className="shrink-0 text-xs text-muted-foreground">{state === "saving" ? t("common.saving") : state === "saved" ? t("common.saved") : ""}</span>
        </div>
        {onTimestampClick && stamps.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {stamps.map((m, i) => {
              const [a, b, c] = [Number(m[1]), Number(m[2]), Number(m[3] ?? 0)]; const sec = m[3] ? a * 3600 + b * 60 + c : a * 60 + b;
              return <button key={i} onClick={() => onTimestampClick(sec)} className="rounded-full bg-accent px-2 py-0.5 text-xs" dir="ltr">{m[0]}</button>;
            })}
          </div>
        )}
        <textarea ref={area} value={content} onChange={(e) => setContent(e.target.value)} placeholder={t("notes.placeholder")}
          className="mt-4 min-h-[300px] flex-1 resize-none bg-transparent text-sm leading-7 outline-none" />
      </div>
    );
  },
);
