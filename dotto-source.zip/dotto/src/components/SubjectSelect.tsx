import { useList } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
export function SubjectSelect({ value, onChange }: { value: string | null; onChange: (v: string | null) => void }) {
  const { data = [] } = useList("subjects", "name", true);
  const { t } = useI18n();
  return (
    <select value={value ?? ""} onChange={(e) => onChange(e.target.value || null)}
      className="h-10 w-full rounded-xl border border-input bg-glass px-3 text-sm">
      <option value="" className="bg-popover">{t("common.subject")}: {t("common.none")}</option>
      {data.map((s) => <option key={s.id} value={s.id} className="bg-popover">{s.name}</option>)}
    </select>
  );
}
