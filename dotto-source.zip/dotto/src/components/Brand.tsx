import { useI18n } from "@/lib/i18n";
export function Wordmark({ className = "text-3xl" }: { className?: string }) {
  return (
    <span className={`font-display font-semibold tracking-[0.08em] ${className}`} dir="ltr">
      DOTTO<span className="text-blush">.</span>
    </span>
  );
}
export function BrandLockup() {
  const { t } = useI18n();
  return (
    <div className="text-center">
      <Wordmark className="text-6xl sm:text-7xl" />
      <p className="motto mt-4 text-blush">{t("motto")}</p>
      <p className="mt-3 font-display text-xl italic text-muted-foreground">{t("tagline")}</p>
    </div>
  );
}
export function ChromeBackground() {
  return (
    <div className="chrome-bg" aria-hidden>
      <div className="chrome-blob b1" /><div className="chrome-blob b2" />
      <div className="chrome-blob b3" /><div className="chrome-blob b4" />
      <div className="chrome-sheen" />
    </div>
  );
}
