import { useRef, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { useQueryClient } from '@tanstack/react-query';
import { FileText, Upload, Download, Trash2, RotateCcw, Brain } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useList } from '@/lib/data';
import { useI18n } from '@/lib/i18n';
import type { TKey } from '@/lib/i18n-dict';
import { validPdf } from '@/lib/document-rules';
import { finishDocument } from '@/lib/documents.functions';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';

export function DocumentsLibrary() {
  const {t}=useI18n(); const {data:docs=[],isLoading,error}=useList('documents'); const qc=useQueryClient(); const finish=useServerFn(finishDocument);
  const input=useRef<HTMLInputElement>(null); const [busy,setBusy]=useState(false); const [progress,setProgress]=useState(0); const [phase,setPhase]=useState(''); const [drag,setDrag]=useState(false);
  const [viewer,setViewer]=useState<{url:string;title:string}|null>(null);
  const refresh=()=>qc.invalidateQueries({queryKey:['documents']});
  async function process(file: Blob,id:string) {
    setPhase(t('docs.processing')); setProgress(0);
    const {extractPdf}=await import('@/lib/pdf-browser');
    const result=await extractPdf(file,(p,n)=>setProgress(Math.round(p/n*100)));
    await finish({data:{id,...result}}); await refresh();
  }
  async function upload(files: File[]) {
    if (busy) return; setBusy(true);
    try {
      const {data:auth}=await supabase.auth.getUser(); if (!auth.user) throw new Error('ai.signIn');
      for (const file of files) {
        if (!validPdf(file.name,file.size,await file.slice(0,5).text())) {toast.error(t('docs.invalid'));continue;}
        const id=crypto.randomUUID(); const path=`${auth.user.id}/${id}.pdf`; setPhase(file.name);setProgress(0);
        const {data:session}=await supabase.auth.getSession(); if (!session.session) throw new Error('ai.signIn');
        await new Promise<void>((resolve,reject)=>{
          const xhr=new XMLHttpRequest();
          xhr.open('POST',`${import.meta.env['VITE_SUPABASE_URL']}/storage/v1/object/student-documents/${path}`);
          xhr.setRequestHeader('Authorization',`Bearer ${session.session?.access_token}`);xhr.setRequestHeader('apikey',import.meta.env['VITE_SUPABASE_PUBLISHABLE_KEY']);xhr.setRequestHeader('Content-Type','application/pdf');
          xhr.upload.onprogress=e=>{if(e.lengthComputable)setProgress(Math.round(e.loaded/e.total*100));};
          xhr.onload=()=>xhr.status>=200&&xhr.status<300?resolve():reject(new Error('common.error'));xhr.onerror=()=>reject(new Error('common.error'));xhr.send(file);
        });
        const row=await supabase.from('documents').insert({id,title:file.name.slice(0,255),storage_path:path,size_bytes:file.size});
        if (row.error) {await supabase.storage.from('student-documents').remove([path]);throw row.error;}
        await refresh();
        try {await process(file,id);} catch(e) {await supabase.from('documents').update({status:'failed'}).eq('id',id);toast.error(t((e instanceof Error && e.message==='docs.tooManyPages'?'docs.tooManyPages':'docs.failed')));await refresh();}
      }
    } catch(e) {toast.error(t(e instanceof Error && e.message==='ai.signIn'?'ai.signIn':'common.error'));} finally {setBusy(false);setPhase('');if(input.current)input.current.value='';}
  }
  async function open(doc:typeof docs[number],download=false) {
    const result=await supabase.storage.from('student-documents').createSignedUrl(doc.storage_path,3600,download?{download:doc.title}:undefined);
    if(result.error){toast.error(t('common.error'));return;}
    if(download){const a=document.createElement('a');a.href=result.data.signedUrl;a.download=doc.title;a.click();}else setViewer({url:result.data.signedUrl,title:doc.title});
  }
  async function remove(doc:typeof docs[number]) {
    if(!confirm(t('docs.deleteConfirm')))return;
    const storage=await supabase.storage.from('student-documents').remove([doc.storage_path]);if(storage.error){toast.error(t('common.error'));return;}
    const row=await supabase.from('documents').delete().eq('id',doc.id);if(row.error)toast.error(t('common.error'));await refresh();
  }
  async function retry(doc:typeof docs[number]) {
    setBusy(true);try{const file=await supabase.storage.from('student-documents').download(doc.storage_path);if(file.error||!file.data)throw new Error();await process(file.data,doc.id);}catch{toast.error(t('docs.failed'));}finally{setBusy(false);setPhase('');}
  }
  return <div className="space-y-6">
    <div onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);void upload(Array.from(e.dataTransfer.files));}} className={`rounded-2xl border border-dashed p-7 text-center ${drag?'bg-accent border-primary':'border-input'}`}>
      <Upload className="mx-auto mb-3 size-8 text-blush"/><p className="mb-1">{t('docs.drop')}</p><p className="mb-4 text-xs text-muted-foreground">{t('docs.limits')}</p>
      <input ref={input} type="file" accept="application/pdf,.pdf" multiple className="hidden" onChange={e=>void upload(Array.from(e.target.files??[]))}/>
      <Button onClick={()=>input.current?.click()} disabled={busy}><Upload/>{t('docs.upload')}</Button>
      {busy&&<div className="mx-auto mt-4 max-w-sm" role="status"><p className="mb-2 truncate text-sm">{phase} · {progress}%</p><Progress value={progress}/></div>}
    </div>
    {isLoading?<p>{t('common.loading')}</p>:error?<p role="alert">{t('common.error')}</p>:docs.length===0?<p className="py-8 text-center text-muted-foreground">{t('docs.empty')}</p>:<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{docs.map(doc=><article key={doc.id} className="glass flex min-w-0 flex-col p-5"><FileText className="mb-4 size-8 text-blush"/><h2 className="break-words text-xl">{doc.title}</h2><p className="my-2 text-xs text-muted-foreground">{(doc.size_bytes/1024/1024).toFixed(2)} MB · {doc.page_count} {t('docs.pages')}</p><p className="mb-4 text-xs">{t(`docs.${doc.status}` as TKey)}{doc.processing_error&&` (${doc.processing_error})`}</p><div className="mt-auto flex flex-wrap gap-2"><Button variant="secondary" size="sm" onClick={()=>void open(doc)}>{t('common.open')}</Button><Button variant="ghost" size="icon" title={t('docs.download')} aria-label={t('docs.download')} onClick={()=>void open(doc,true)}><Download/></Button><Button variant="ghost" size="icon" title={t('common.delete')} aria-label={t('common.delete')} onClick={()=>void remove(doc)}><Trash2/></Button>{['failed','processing','partial'].includes(doc.status)&&<Button variant="ghost" size="icon" disabled={busy} title={t('docs.retry')} aria-label={t('docs.retry')} onClick={()=>void retry(doc)}><RotateCcw/></Button>}{['ready','partial'].includes(doc.status)&&<Button asChild size="sm"><Link to="/assistant" search={{document:doc.id}}><Brain/>{t('catalog.ai')}</Link></Button>}</div></article>)}</div>}
    <Dialog open={!!viewer} onOpenChange={v=>{if(!v)setViewer(null);}}><DialogContent className="h-[85dvh] max-w-5xl"><DialogTitle className="truncate pe-8">{viewer?.title}</DialogTitle>{viewer&&<object data={viewer.url} type="application/pdf" className="h-full min-h-0 w-full"><a href={viewer.url} target="_blank" rel="noreferrer">{t('common.open')}</a></object>}</DialogContent></Dialog>
  </div>;
}
