import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { BarChart3, BookOpen, Brain, CalendarDays, CheckSquare, Home, LibraryBig, LogOut, NotebookPen, Settings } from "lucide-react";
import type { ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/lib/i18n";
import type { TKey } from "@/lib/i18n-dict";
import { Wordmark } from "./Brand";

const NAV: { to: string; key: TKey; icon: typeof Home }[] = [
  { to: "/home", key: "nav.home", icon: Home },
  { to: "/catalog", key: "nav.catalog", icon: LibraryBig },
  { to: "/assistant", key: "nav.ai", icon: Brain },
  { to: "/study-plans", key: "nav.plans", icon: BookOpen },
  { to: "/tasks", key: "nav.tasks", icon: CheckSquare },
  { to: "/progress", key: "nav.progress", icon: BarChart3 },
  { to: "/calendar", key: "nav.calendar", icon: CalendarDays },
  { to: "/notes", key: "nav.notes", icon: NotebookPen },
  { to: "/settings", key: "nav.settings", icon: Settings },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const qc = useQueryClient();
  const navigate = useNavigate();
  async function signOut() {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }
  return (
    <div className="min-h-screen lg:flex">
      <aside className="glass-strong sticky top-4 m-4 hidden h-[calc(100vh-2rem)] w-64 shrink-0 flex-col p-6 lg:flex">
        <Link to="/home"><Wordmark className="text-3xl" /></Link>
        <nav className="mt-10 flex flex-1 flex-col gap-1">
          {NAV.map(({ to, key, icon: Icon }) => (
            <Link key={to} to={to} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground transition hover:bg-sidebar-accent hover:text-foreground"
              activeProps={{ className: "bg-sidebar-accent text-foreground! shadow-glow" }}>
              <Icon className="h-4 w-4 shrink-0" strokeWidth={1.5} />{t(key)}
            </Link>
          ))}
        </nav>
        <button onClick={signOut} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground">
          <LogOut className="h-4 w-4 rtl:rotate-180" strokeWidth={1.5} />{t("nav.signout")}
        </button>
      </aside>
      <main className="min-w-0 flex-1 px-4 pb-28 pt-6 sm:px-8 lg:pb-10 lg:pt-8">{children}</main>
      <nav className="glass-strong fixed inset-x-2 bottom-2 z-40 flex px-1 py-1.5 lg:hidden">
        {NAV.map(({ to, key, icon: Icon }) => (
          <Link key={to} to={to} className="flex min-w-0 flex-1 flex-col items-center gap-1 rounded-xl px-0.5 py-1.5 text-[9px] text-muted-foreground"
            activeProps={{ className: "bg-sidebar-accent text-foreground!" }}>
            <Icon className="h-5 w-5" strokeWidth={1.5} /><span className="w-full truncate text-center">{t(key)}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function PageHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <header className="mb-8 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 fade-up">
      <h1 className="truncate text-4xl font-semibold sm:text-5xl">{title}</h1>
      {action}
    </header>
  );
}
