import { Languages } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { LANGS } from "@/lib/i18n-dict";
export function LangSwitch() {
  const { lang, setLang } = useI18n();
  return (
    <div className="glass flex items-center gap-1 rounded-full! p-1">
      <Languages className="mx-1.5 h-4 w-4 text-muted-foreground" aria-hidden />
      {LANGS.map((l) => (
        <button key={l.code} type="button" onClick={() => setLang(l.code)} aria-pressed={lang === l.code}
          className={`rounded-full px-2.5 py-1 text-xs transition ${lang === l.code ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
          {l.code.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
