import { useEffect, useRef, useState } from 'react';
import type { UIMessage, ChatStatus } from 'ai';
import { useQueryClient } from '@tanstack/react-query';
import { Copy, Trash2, Globe, ArrowUp } from 'lucide-react';
import { useList } from '@/lib/data';
import { useI18n } from '@/lib/i18n';
import type { TKey } from '@/lib/i18n-dict';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Wordmark } from '@/components/Brand';
import { Conversation, ConversationContent, ConversationScrollButton } from '@/components/ai-elements/conversation';
import { Message, MessageContent, MessageResponse } from '@/components/ai-elements/message';
import { PromptInput, PromptInputTextarea, PromptInputFooter, PromptInputSubmit } from '@/components/ai-elements/prompt-input';
import { Shimmer } from '@/components/ai-elements/shimmer';

const ACTIONS=['summary','simple','important','notes','flashcards','quiz','concepts'] as const;
export function AssistantChat({initialDocument}:{initialDocument?:string}) {
  const {t,lang}=useI18n();const qc=useQueryClient();const {data:history=[],isLoading,error:loadError}=useList('assistant_messages','created_at',true);const {data:docs=[]}=useList('documents');
  const [documentId,setDocumentId]=useState(initialDocument??'none');const [draft,setDraft]=useState('');const [status,setStatus]=useState<ChatStatus>('ready');const [pending,setPending]=useState<UIMessage[]>([]);const [error,setError]=useState<TKey|null>(null);const [research,setResearch]=useState(false);
  const textarea=useRef<HTMLTextAreaElement>(null);const abort=useRef<AbortController|null>(null);const busy=status==='submitted'||status==='streaming';
  useEffect(()=>{textarea.current?.focus();},[documentId]);useEffect(()=>()=>abort.current?.abort(),[]);
  const messages:UIMessage[]=[...history.map(m=>({id:m.id,role:m.role as 'user'|'assistant',parts:[{type:'text' as const,text:m.content}]})),...pending];
  async function send(text:string,action:'ask'|typeof ACTIONS[number]='ask') {
    if(busy||!text.trim()||text.length>12000)return;
    const requestId=crypto.randomUUID();setDraft('');setError(null);setStatus('submitted');const answerId=crypto.randomUUID();
    setPending([{id:requestId,role:'user',parts:[{type:'text',text}]},{id:answerId,role:'assistant',parts:[{type:'text',text:''}]}]);textarea.current?.focus();
    const cancel=new AbortController();abort.current=cancel;let done=false;
    try {
      const {data:session}=await supabase.auth.getSession();if(!session.session)throw new Error('ai.signIn');
      const response=await fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${session.session.access_token}`},body:JSON.stringify({requestId,message:text,documentId:documentId==='none'?null:documentId,action,language:lang,research}),signal:cancel.signal});
      if(!response.ok){const body=await response.json();throw new Error(body.error??'ai.failed');}
      const reader=response.body?.getReader();if(!reader)throw new Error('ai.failed');const decoder=new TextDecoder();let buffer='';
      while(true){const chunk=await reader.read();if(chunk.done)break;buffer+=decoder.decode(chunk.value,{stream:true});const lines=buffer.split('\n');buffer=lines.pop()??'';for(const line of lines){if(!line)continue;const event=JSON.parse(line);if(event.type==='delta'){setStatus('streaming');setPending(old=>old.map(m=>m.id===answerId?{...m,parts:m.parts.map(p=>p.type==='text'?{...p,text:p.text+event.text}:p)}:m));}if(event.type==='error')throw new Error(event.error);if(event.type==='done')done=true;}}
      if(!done)throw new Error('ai.incomplete');
      await qc.invalidateQueries({queryKey:['assistant_messages']});setPending([]);setStatus('ready');
    } catch(e) {
      if(cancel.signal.aborted){setStatus('ready');}else{setError((e instanceof Error&&/^(ai|docs)\./.test(e.message)?e.message:'ai.failed') as TKey);setStatus('error');}
      // Keep partial output visible, while persisted history remains the source of truth on reload.
    }finally{abort.current=null;textarea.current?.focus();}
  }
  async function clear(){if(busy||!confirm(t('ai.clearConfirm')))return;const {data:auth}=await supabase.auth.getUser();if(!auth.user)return;const result=await supabase.from('assistant_messages').delete().eq('user_id',auth.user.id);if(result.error){setError('common.error');return;}setPending([]);setError(null);await qc.invalidateQueries({queryKey:['assistant_messages']});textarea.current?.focus();}
  return <div className="flex h-[calc(100dvh-14rem)] min-h-[550px] flex-col gap-4">
    <div className="flex flex-wrap items-center gap-3"><div className="min-w-0 flex-1"><Select value={documentId} onValueChange={setDocumentId} disabled={busy}><SelectTrigger aria-label={t('ai.document')}><SelectValue/></SelectTrigger><SelectContent><SelectItem value="none">{t('ai.general')}</SelectItem>{docs.filter(d=>['ready','partial'].includes(d.status)).map(d=><SelectItem key={d.id} value={d.id}>{d.title}</SelectItem>)}</SelectContent></Select></div><Button variant="ghost" size="icon" onClick={()=>void clear()} disabled={busy} aria-label={t('ai.clear')} title={t('ai.clear')}><Trash2/></Button></div>
    {documentId!=='none'&&<div className="flex flex-wrap gap-2">{ACTIONS.map(a=><Button key={a} variant="secondary" size="sm" disabled={busy||isLoading} onClick={()=>void send(t(`ai.${a}`),a)}>{t(`ai.${a}`)}</Button>)}</div>}
    <Conversation className="min-h-0 flex-1"><ConversationContent className="px-1 py-4">
      {isLoading?<Shimmer>{t('common.loading')}</Shimmer>:loadError?<p role="alert">{t('common.error')}</p>:messages.length===0?<div className="py-14 text-center"><Wordmark className="text-4xl"/><h2 className="mt-5 text-3xl">{t('ai.empty')}</h2></div>:messages.map(m=><Message key={m.id} from={m.role} className={m.role==='user'?'ms-auto':'me-auto'}><MessageContent className={m.role==='user'?'bg-primary! text-primary-foreground!':'bg-transparent break-words'}>{m.parts.map((part,i)=>part.type==='text'&&<MessageResponse key={i}>{part.text}</MessageResponse>)}</MessageContent>{m.role==='assistant'&&m.parts.some(p=>p.type==='text'&&p.text)&&<Button variant="ghost" size="icon" aria-label={t('ai.copy')} title={t('ai.copy')} onClick={()=>void navigator.clipboard.writeText(m.parts.flatMap(p=>p.type==='text'?[p.text]:[]).join('\n'))}><Copy/></Button>}</Message>)}
      {status==='submitted'&&<Shimmer>{t('ai.thinking')}</Shimmer>}
    </ConversationContent><ConversationScrollButton aria-label={t('common.open')}/></Conversation>
    {error&&<p role="alert" className="text-sm text-destructive">{t(error)}</p>}
    <PromptInput onSubmit={async()=>{await send(draft);}}><PromptInputTextarea ref={textarea} autoFocus value={draft} maxLength={12000} disabled={isLoading} onChange={e=>setDraft(e.target.value)} placeholder={t('ai.placeholder')} aria-label={t('ai.placeholder')} className="min-h-20"/><PromptInputFooter className="justify-between">{documentId==='none'?<label className="flex items-center gap-2 text-xs text-muted-foreground"><Globe className="size-4"/><Switch checked={research} onCheckedChange={setResearch} disabled={busy}/>{t('ai.research')}</label>:<span className="truncate text-xs text-muted-foreground">{t('ai.document')}</span>}<PromptInputSubmit status={status} disabled={(!busy&&!draft.trim())||isLoading} onStop={()=>abort.current?.abort()} aria-label={busy?t('ai.stop'):t('ai.send')} className="size-9 shrink-0">{!busy&&<ArrowUp/>}</PromptInputSubmit></PromptInputFooter></PromptInput>
  </div>;
}
