import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, Trash2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { useList, useRemove, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { planProgress } from "@/lib/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Bar } from "./home";

export const Route = createFileRoute("/_authenticated/study-plans/$id")({
  head: () => ({ meta: [{ title: "Study plan — DOTTO" }, { name: "description", content: "Lessons and progress for this study plan." }, { property: "og:title", content: "Study plan — DOTTO" }, { property: "og:description", content: "Lessons and progress for this study plan." }] }),
  component: PlanDetail,
});

function PlanDetail() {
  const { id } = Route.useParams();
  const { t } = useI18n();
  const navigate = useNavigate();
  const { data: plans = [] } = useList("study_plans");
  const { data: lessons = [] } = useList("lessons", "position", true);
  const { data: tasks = [] } = useList("tasks");
  const save = useUpsert("lessons");
  const del = useRemove("lessons");
  const delPlan = useRemove("study_plans");
  const [title, setTitle] = useState("");
  const plan = plans.find((p) => p.id === id);
  const mine = lessons.filter((l) => l.plan_id === id);
  if (!plan) return <p className="text-muted-foreground">{t("common.loading")}</p>;
  const v = planProgress(id, lessons);
  async function add(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    await save.mutateAsync({ plan_id: id, title, position: mine.length });
    setTitle("");
  }
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Link to="/study-plans" className="inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4 rtl:rotate-180" />{t("common.back")}</Link>
      <section className="glass p-8">
        <h1 className="text-4xl">{plan.title}</h1>
        {plan.description && <p className="mt-2 text-muted-foreground">{plan.description}</p>}
        <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
          {plan.exam_target && <span>{t("plans.examTarget")}: {plan.exam_target}</span>}
          {plan.start_date && <span>{t("plans.start")}: {plan.start_date}</span>}
          {plan.deadline && <span>{t("plans.deadline")}: {plan.deadline}</span>}
        </div>
        <div className="mt-6 flex items-center gap-3"><div className="flex-1"><Bar value={v} /></div><span className="font-display text-2xl">{v}%</span></div>
      </section>
      <section className="glass p-6">
        <h2 className="mb-4 text-2xl">{t("plans.lessons")}</h2>
        <ul className="space-y-2">
          {mine.map((l) => (
            <li key={l.id} className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-muted">
              <Checkbox checked={l.completed} onCheckedChange={(c) => save.mutate({ id: l.id, plan_id: id, title: l.title, completed: !!c, completed_at: c ? new Date().toISOString() : null })} />
              <span className={`flex-1 text-sm ${l.completed ? "text-muted-foreground line-through" : ""}`}>{l.title}</span>
              <button onClick={() => del.mutate(l.id)} aria-label={t("common.delete")} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
            </li>
          ))}
        </ul>
        <form onSubmit={add} className="mt-4 flex gap-2">
          <Input placeholder={t("plans.addLesson")} value={title} onChange={(e) => setTitle(e.target.value)} />
          <button className="rounded-xl bg-gradient-blush px-5 text-sm font-semibold text-primary-foreground">{t("common.add")}</button>
        </form>
      </section>
      {tasks.some((x) => x.plan_id === id) && (
        <section className="glass p-6">
          <h2 className="mb-3 text-2xl">{t("nav.tasks")}</h2>
          {tasks.filter((x) => x.plan_id === id).map((x) => <p key={x.id} className="text-sm">{x.completed ? "✓ " : "• "}{x.title}</p>)}
        </section>
      )}
      <button onClick={async () => { await delPlan.mutateAsync(id); navigate({ to: "/study-plans" }); }} className="text-sm text-destructive">{t("common.delete")}</button>
    </div>
  );
}
