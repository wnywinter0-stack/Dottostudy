import { createFileRoute } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useList, useProfile, useRemove, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { PageHeader } from "@/components/AppShell";
import { LangSwitch } from "@/components/LangSwitch";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings — DOTTO" }, { name: "description", content: "Manage your DOTTO profile and preferences." }, { property: "og:title", content: "Settings — DOTTO" }, { property: "og:description", content: "Manage your DOTTO profile and preferences." }] }),
  component: Settings,
});

function Settings() {
  const { t } = useI18n();
  const qc = useQueryClient();
  const { data: me } = useProfile();
  const { data: subjects = [] } = useList("subjects", "name", true);
  const addSub = useUpsert("subjects");
  const delSub = useRemove("subjects");
  const [p, setP] = useState({ full_name: "", exam_date: "", exam_label: "" });
  const [pw, setPw] = useState({ current: "", next: "" });
  const [sub, setSub] = useState("");
  useEffect(() => {
    if (me?.profile) setP({ full_name: me.profile.full_name ?? "", exam_date: me.profile.exam_date ?? "", exam_label: me.profile.exam_label ?? "" });
  }, [me?.profile]);
  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    if (!me) return;
    const { error } = await supabase.from("profiles").update({ ...p, exam_date: p.exam_date || null }).eq("id", me.user.id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["profile"] }); toast.success(t("common.saved"));
  }
  async function changePw(e: FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password: pw.next, current_password: pw.current } as never);
    if (error) return void toast.error(error.message);
    setPw({ current: "", next: "" }); toast.success(t("common.saved"));
  }
  const card = "glass space-y-4 p-6";
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title={t("settings.title")} />
      <form onSubmit={saveProfile} className={card}>
        <h2 className="text-2xl">{t("settings.profile")}</h2>
        <p className="text-sm text-muted-foreground">{me?.user.email}</p>
        <Input placeholder={t("auth.fullname")} value={p.full_name} onChange={(e) => setP({ ...p, full_name: e.target.value })} />
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-xs text-muted-foreground">{t("settings.examLabel")}<Input value={p.exam_label} onChange={(e) => setP({ ...p, exam_label: e.target.value })} /></label>
          <label className="text-xs text-muted-foreground">{t("settings.exam")}<Input type="date" min="2026-09-01" max="2027-08-31" value={p.exam_date} onChange={(e) => setP({ ...p, exam_date: e.target.value })} /></label>
        </div>
        <button className="rounded-xl bg-gradient-blush px-6 py-2.5 text-sm font-semibold text-primary-foreground">{t("common.save")}</button>
      </form>
      <section className={card}>
        <h2 className="text-2xl">{t("settings.language")}</h2>
        <LangSwitch />
      </section>
      <section className={card}>
        <h2 className="text-2xl">{t("settings.subjects")}</h2>
        <div className="flex flex-wrap gap-2">{subjects.map((s) => (
          <span key={s.id} className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1.5 text-sm">{s.name}<button onClick={() => delSub.mutate(s.id)} aria-label={t("common.delete")}><Trash2 className="h-3 w-3" /></button></span>
        ))}</div>
        <form onSubmit={async (e) => { e.preventDefault(); if (!sub.trim()) return; await addSub.mutateAsync({ name: sub.trim() }); setSub(""); }} className="flex gap-2">
          <Input placeholder={t("settings.addSubject")} value={sub} onChange={(e) => setSub(e.target.value)} />
          <button className="rounded-xl bg-gradient-blush px-5 text-sm font-semibold text-primary-foreground">{t("common.add")}</button>
        </form>
      </section>
      <form onSubmit={changePw} className={card}>
        <h2 className="text-2xl">{t("settings.password")}</h2>
        <Input type="password" required placeholder={t("settings.current")} value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
        <Input type="password" required minLength={8} placeholder={t("auth.newPassword")} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
        <button className="rounded-xl bg-gradient-blush px-6 py-2.5 text-sm font-semibold text-primary-foreground">{t("auth.updatePassword")}</button>
      </form>
    </div>
  );
}
