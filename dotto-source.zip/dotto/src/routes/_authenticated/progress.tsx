import { createFileRoute } from "@tanstack/react-router";
import { Bar as RBar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { useList } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { pct, planProgress, subjectProgress } from "@/lib/progress";
import { PageHeader } from "@/components/AppShell";
import { Bar } from "./home";

export const Route = createFileRoute("/_authenticated/progress")({
  head: () => ({ meta: [{ title: "Progress — DOTTO" }, { name: "description", content: "Your real study analytics." }, { property: "og:title", content: "Progress — DOTTO" }, { property: "og:description", content: "Your real study analytics." }] }),
  component: Progress,
});

function Progress() {
  const { t, lang } = useI18n();
  const { data: plans = [] } = useList("study_plans");
  const { data: lessons = [] } = useList("lessons");
  const { data: tasks = [] } = useList("tasks");
  const { data: sessions = [] } = useList("study_sessions");
  const { data: subjects = [] } = useList("subjects");
  const prog = subjectProgress(plans, lessons);
  const done = lessons.filter((l) => l.completed).length;
  const hours = (sessions.reduce((a, s) => a + s.seconds, 0) / 3600).toFixed(1);
  const days = [...Array(7)].map((_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const key = d.toDateString();
    return {
      day: d.toLocaleDateString(lang, { weekday: "short" }),
      minutes: Math.round(sessions.filter((s) => new Date(s.started_at).toDateString() === key).reduce((a, s) => a + s.seconds, 0) / 60),
      lessons: lessons.filter((l) => l.completed_at && new Date(l.completed_at).toDateString() === key).length,
    };
  });
  const stats = [
    { k: t("home.overall"), v: prog.overall + "%" }, { k: t("progress.lessonsDone"), v: done },
    { k: t("progress.lessonsLeft"), v: lessons.length - done }, { k: t("progress.hours"), v: hours },
    { k: t("progress.tasksDone"), v: tasks.filter((x) => x.completed).length + " / " + tasks.length },
  ];
  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <PageHeader title={t("progress.title")} />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        {stats.map((s) => <div key={s.k} className="glass p-5"><p className="text-xs text-muted-foreground">{s.k}</p><p className="mt-2 font-display text-4xl" dir="ltr">{s.v}</p></div>)}
      </div>
      <section className="glass p-6">
        <h2 className="mb-4 text-2xl">{t("progress.weekly")}</h2>
        <div className="h-64" dir="ltr">
          <ResponsiveContainer>
            <BarChart data={days}>
              <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }} />
              <RBar dataKey="minutes" fill="var(--blush)" radius={[8, 8, 0, 0]} />
              <RBar dataKey="lessons" fill="var(--mauve)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
      <div className="grid gap-6 md:grid-cols-2">
        <section className="glass space-y-4 p-6">
          <h2 className="text-2xl">{t("progress.subjects")}</h2>
          {[...prog.bySubject.entries()].map(([sid, v]) => (
            <div key={sid ?? "none"}><div className="mb-1 flex justify-between text-sm"><span>{subjects.find((s) => s.id === sid)?.name ?? t("common.none")}</span><span>{pct(v.done, v.total)}%</span></div><Bar value={pct(v.done, v.total)} /></div>
          ))}
        </section>
        <section className="glass space-y-4 p-6">
          <h2 className="text-2xl">{t("progress.plans")}</h2>
          {plans.map((p) => <div key={p.id}><div className="mb-1 flex justify-between text-sm"><span className="truncate">{p.title}</span><span>{planProgress(p.id, lessons)}%</span></div><Bar value={planProgress(p.id, lessons)} /></div>)}
        </section>
      </div>
    </div>
  );
}
