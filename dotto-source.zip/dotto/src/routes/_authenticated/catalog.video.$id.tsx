import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Clock, ExternalLink, Plus } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useList, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { NoteEditor, type NoteEditorHandle } from "@/components/NoteEditor";

export const Route = createFileRoute("/_authenticated/catalog/video/$id")({
  head: () => ({ meta: [{ title: "Video workspace — DOTTO" }, { name: "description", content: "Watch and take notes side by side." }, { property: "og:title", content: "Video workspace — DOTTO" }, { property: "og:description", content: "Watch and take notes side by side." }] }),
  component: VideoWorkspace,
});

type YTPlayer = { getCurrentTime: () => number; seekTo: (s: number, a: boolean) => void; destroy: () => void };
declare global { interface Window { YT?: { Player: new (el: HTMLElement, o: object) => YTPlayer }; onYouTubeIframeAPIReady?: () => void } }

function loadYT(): Promise<void> {
  if (window.YT?.Player) return Promise.resolve();
  return new Promise((res) => {
    window.onYouTubeIframeAPIReady = () => res();
    if (!document.getElementById("yt-api")) {
      const s = document.createElement("script"); s.id = "yt-api"; s.src = "https://www.youtube.com/iframe_api"; document.head.appendChild(s);
    }
  });
}

function VideoWorkspace() {
  const { id } = Route.useParams();
  const { t } = useI18n();
  const { data: videos = [] } = useList("videos");
  const { data: notes = [] } = useList("notes", "updated_at");
  const save = useUpsert("notes");
  const video = videos.find((v) => v.id === id);
  const mine = notes.filter((n) => n.video_id === id);
  const [sel, setSel] = useState<string | null>(null);
  const current = mine.find((n) => n.id === sel) ?? mine[0] ?? null;
  const host = useRef<HTMLDivElement>(null);
  const player = useRef<YTPlayer | null>(null);
  const editor = useRef<NoteEditorHandle>(null);

  useEffect(() => {
    if (!video || !host.current) return;
    let alive = true;
    const isList = video.kind === "playlist";
    loadYT().then(() => {
      if (!alive || !host.current || !window.YT) return;
      const el = document.createElement("div"); host.current.innerHTML = ""; host.current.appendChild(el);
      player.current = new window.YT.Player(el, {
        width: "100%", height: "100%",
        ...(isList ? { playerVars: { listType: "playlist", list: video.youtube_id } } : { videoId: video.youtube_id ?? undefined }),
      });
    });
    return () => { alive = false; player.current?.destroy(); player.current = null; };
  }, [video?.id]);

  function stamp() {
    const s = Math.floor(player.current?.getCurrentTime() ?? 0);
    const m = Math.floor(s / 60), r = String(s % 60).padStart(2, "0");
    editor.current?.insert(`[${m}:${r}] `);
  }
  if (!video) return <p className="text-muted-foreground">{t("common.loading")}</p>;
  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link to="/catalog" className="inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4 rtl:rotate-180" />{t("common.back")}</Link>
        <a href={video.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">{t("catalog.external")}<ExternalLink className="h-3 w-3" /></a>
      </div>
      <h1 className="text-3xl">{video.title}</h1>
      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div className="glass overflow-hidden p-0!"><div ref={host} className="aspect-video w-full [&_iframe]:h-full [&_iframe]:w-full" /></div>
        <section className="glass flex min-h-[420px] flex-col p-5">
          <div className="mb-3 flex items-center gap-2">
            <p className="motto flex-1 text-muted-foreground">{t("catalog.watchNotes")}</p>
            <button onClick={stamp} disabled={!current} className="inline-flex items-center gap-1 rounded-full bg-accent px-3 py-1.5 text-xs disabled:opacity-50"><Clock className="h-3.5 w-3.5" />{t("catalog.timestamp")}</button>
            <button onClick={async () => { const n = await save.mutateAsync({ video_id: id, subject_id: video.subject_id, title: video.title }); setSel(n.id); }}
              aria-label={t("notes.new")} className="rounded-full bg-gradient-blush p-1.5 text-primary-foreground"><Plus className="h-4 w-4" /></button>
          </div>
          {mine.length > 1 && (
            <div className="mb-3 flex flex-wrap gap-1.5">{mine.map((n) => <button key={n.id} onClick={() => setSel(n.id)} className={`rounded-full px-2.5 py-1 text-xs ${current?.id === n.id ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{n.title}</button>)}</div>
          )}
          {current ? <NoteEditor ref={editor} note={current} onTimestampClick={(s) => player.current?.seekTo(s, true)} />
            : <p className="grid flex-1 place-items-center text-sm text-muted-foreground">{t("notes.empty")}</p>}
        </section>
      </div>
    </div>
  );
}
