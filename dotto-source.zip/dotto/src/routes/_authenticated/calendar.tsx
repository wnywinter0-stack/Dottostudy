import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import { useList } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { PageHeader } from "@/components/AppShell";

export const Route = createFileRoute("/_authenticated/calendar")({
  head: () => ({ meta: [{ title: "Calendar — DOTTO" }, { name: "description", content: "Schedule study sessions." }, { property: "og:title", content: "Calendar — DOTTO" }, { property: "og:description", content: "Schedule study sessions." }] }),
  component: Cal,
});

function Cal() {
  const { t } = useI18n();
  const { data: tasks = [] } = useList("tasks", "due_at", true);
  const scheduled = tasks.filter((x) => x.due_at && !x.completed);
  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <PageHeader title={t("calendar.title")} />
      <section className="glass p-8 text-center">
        <CalendarDays className="mx-auto h-10 w-10 text-blush" strokeWidth={1.2} />
        <h2 className="mt-4 text-2xl">{t("calendar.notConnected")}</h2>
        <p className="mx-auto mt-2 max-w-lg text-sm text-muted-foreground">{t("calendar.explain")}</p>
        <a href="https://calendar.google.com" target="_blank" rel="noreferrer" className="mt-6 inline-block rounded-full bg-gradient-blush px-6 py-2.5 text-sm font-semibold text-primary-foreground">{t("calendar.open")}</a>
      </section>
      <section className="glass p-6">
        <h2 className="mb-4 text-2xl">{t("calendar.local")}</h2>
        {scheduled.length === 0 ? <p className="text-sm text-muted-foreground">{t("tasks.empty")}</p> :
          <ul className="space-y-2">{scheduled.map((x) => <li key={x.id} className="flex justify-between gap-3 text-sm"><span className="truncate">{x.title}</span><span className="shrink-0 text-muted-foreground">{new Date(x.due_at!).toLocaleString()}</span></li>)}</ul>}
      </section>
    </div>
  );
}
