import { createFileRoute } from '@tanstack/react-router';
import { z } from 'zod';
import { AssistantChat } from '@/components/AssistantChat';
import { PageHeader } from '@/components/AppShell';
import { useI18n } from '@/lib/i18n';
export const Route=createFileRoute('/_authenticated/assistant')({validateSearch:z.object({document:z.string().uuid().optional()}),head:()=>({meta:[{title:'AI Assistant — DOTTO'},{name:'description',content:'Your personal academic assistant and PDF study companion.'},{property:'og:title',content:'AI Assistant — DOTTO'},{property:'og:description',content:'Your personal academic assistant and PDF study companion.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),component:Assistant});
function Assistant(){const {t}=useI18n();const {document}=Route.useSearch();return <div className="mx-auto max-w-4xl"><PageHeader title={t('catalog.ai')}/><AssistantChat key={document??'general'} {...(document?{initialDocument:document}:{})}/></div>;}
