import { createFileRoute, Link } from "@tanstack/react-router";
import { Bell, CalendarClock, Pause, Play, RotateCcw, Save, Search } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { useList, useProfile, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { daysUntil, fmtDuration, subjectProgress, pct } from "@/lib/progress";
import { Wordmark } from "@/components/Brand";
import { LangSwitch } from "@/components/LangSwitch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export const Route = createFileRoute("/_authenticated/home")({
  head: () => ({ meta: [{ title: "Home — DOTTO" }, { name: "description", content: "Your DOTTO study home." },
    { property: "og:title", content: "Home — DOTTO" }, { property: "og:description", content: "Your DOTTO study home." }] }),
  component: Home,
});

export function Bar({ value }: { value: number }) {
  return <div className="h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-gradient-blush transition-all duration-700" style={{ width: `${value}%` }} /></div>;
}

function Home() {
  const { t } = useI18n();
  const { data: me } = useProfile();
  const { data: tasks = [] } = useList("tasks", "due_at", true);
  const { data: plans = [] } = useList("study_plans");
  const { data: lessons = [] } = useList("lessons");
  const { data: subjects = [] } = useList("subjects");
  const { data: notes = [] } = useList("notes");
  const { data: sessions = [] } = useList("study_sessions");
  const [q, setQ] = useState("");

  const name = me?.profile?.full_name || me?.user.email?.split("@")[0] || "";
  const hour = new Date().getHours();
  const greet = t(hour < 12 ? "home.greeting.morning" : hour < 18 ? "home.greeting.afternoon" : "home.greeting.evening");
  const days = daysUntil(me?.profile?.exam_date ?? null);
  const prog = subjectProgress(plans, lessons);
  const now = Date.now();
  const upcoming = tasks.filter((x) => !x.completed).slice(0, 4);
  const overdue = tasks.filter((x) => !x.completed && x.due_at && new Date(x.due_at).getTime() < now);
  const next = tasks.find((x) => !x.completed && x.due_at && new Date(x.due_at).getTime() >= now);
  const todaySec = sessions.filter((s) => new Date(s.started_at).toDateString() === new Date().toDateString()).reduce((a, s) => a + s.seconds, 0);

  const results = useMemo(() => {
    if (q.trim().length < 2) return [];
    const s = q.toLowerCase();
    return [
      ...notes.filter((n) => (n.title + n.content).toLowerCase().includes(s)).map((n) => ({ k: "n" + n.id, label: n.title, to: "/notes" as const })),
      ...plans.filter((p) => p.title.toLowerCase().includes(s)).map((p) => ({ k: "p" + p.id, label: p.title, to: "/study-plans" as const })),
      ...tasks.filter((x) => x.title.toLowerCase().includes(s)).map((x) => ({ k: "t" + x.id, label: x.title, to: "/tasks" as const })),
    ].slice(0, 8);
  }, [q, notes, plans, tasks]);

  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 fade-up">
        <div className="flex min-w-0 items-center gap-4">
          <div className="grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-full bg-gradient-blush font-display text-2xl text-primary-foreground">
            {me?.profile?.avatar_url ? <img src={me.profile.avatar_url} alt="" className="h-full w-full object-cover" /> : name.slice(0, 1).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="lg:hidden"><Wordmark className="text-xl" /></div>
            <p className="text-sm text-muted-foreground">{greet},</p>
            <h1 className="truncate text-3xl font-semibold sm:text-4xl">{name}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger className="glass relative grid h-10 w-10 place-items-center rounded-full!" aria-label="Notifications">
              <Bell className="h-4 w-4" strokeWidth={1.5} />
              {overdue.length > 0 && <span className="absolute -top-0.5 -end-0.5 h-2.5 w-2.5 rounded-full bg-blush" />}
            </PopoverTrigger>
            <PopoverContent className="w-72 space-y-2 text-sm">
              {overdue.length === 0 ? <p className="text-muted-foreground">{t("tasks.empty")}</p> :
                overdue.map((x) => <p key={x.id}><span className="text-blush">{t("tasks.overdue")}:</span> {x.title}</p>)}
            </PopoverContent>
          </Popover>
          <div className="hidden sm:block"><LangSwitch /></div>
        </div>
      </header>

      <div className="relative fade-up">
        <Search className="absolute start-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("home.search")}
          className="glass h-12 w-full rounded-full! ps-11 pe-4 text-sm outline-none focus:ring-1 focus:ring-ring" />
        {results.length > 0 && (
          <div className="glass-strong absolute inset-x-0 top-14 z-30 p-2">
            {results.map((r) => <Link key={r.k} to={r.to} className="block rounded-lg px-3 py-2 text-sm hover:bg-accent">{r.label}</Link>)}
          </div>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <section className="glass p-7 fade-up">
          <p className="motto text-muted-foreground">{t("home.countdown")}</p>
          {days === null ? (
            <Link to="/settings" className="mt-6 inline-block text-blush">{t("home.setExam")} →</Link>
          ) : (
            <>
              <p className="mt-4 font-display text-7xl font-semibold leading-none">{days}</p>
              <p className="mt-2 text-sm text-muted-foreground">{t("home.daysLeft")} · {me?.profile?.exam_label}</p>
            </>
          )}
        </section>
        <StudyTimer todaySec={todaySec} />
      </div>

      <section className="glass p-7 fade-up">
        <div className="flex items-baseline justify-between">
          <p className="motto text-muted-foreground">{t("home.progress")}</p>
          <span className="font-display text-3xl">{prog.overall}%</span>
        </div>
        <div className="mt-3"><Bar value={prog.overall} /></div>
        {plans.length === 0 ? <p className="mt-6 text-sm text-muted-foreground">{t("home.noProgress")}</p> : (
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {[...prog.bySubject.entries()].map(([sid, v]) => (
              <div key={sid ?? "none"}>
                <div className="mb-1.5 flex justify-between text-sm"><span>{subjects.find((s) => s.id === sid)?.name ?? t("common.none")}</span><span className="text-muted-foreground">{pct(v.done, v.total)}%</span></div>
                <Bar value={pct(v.done, v.total)} />
              </div>
            ))}
          </div>
        )}
      </section>

      <div className="grid gap-6 md:grid-cols-2">
        <section className="glass p-7 fade-up">
          <div className="flex justify-between"><p className="motto text-muted-foreground">{t("home.upcoming")}</p><Link to="/tasks" className="text-xs text-blush">{t("common.open")}</Link></div>
          {upcoming.length === 0 ? <p className="mt-6 text-sm text-muted-foreground">{t("home.noTasks")}</p> : (
            <ul className="mt-4 space-y-3">
              {upcoming.map((x) => (
                <li key={x.id} className="flex items-center justify-between gap-3 text-sm">
                  <span className="truncate">{x.title}</span>
                  <span className="shrink-0 text-xs text-muted-foreground">{x.due_at ? new Date(x.due_at).toLocaleDateString() : "—"}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section className="glass p-7 fade-up">
          <p className="motto text-muted-foreground">{t("home.nextSession")}</p>
          <div className="mt-5 flex items-center gap-3">
            <CalendarClock className="h-6 w-6 text-blush" strokeWidth={1.4} />
            <div className="min-w-0 text-sm">
              {next ? <><p className="truncate">{next.title}</p><p className="text-muted-foreground">{new Date(next.due_at!).toLocaleString()}</p></> : <p className="text-muted-foreground">—</p>}
            </div>
          </div>
          <a href="https://calendar.google.com" target="_blank" rel="noreferrer" className="mt-6 inline-block text-sm text-blush">{t("home.openCalendar")} →</a>
        </section>
      </div>

      <div className="flex justify-center pt-4 fade-up">
        <Link to="/catalog" className="rounded-full bg-gradient-blush px-12 py-4 text-sm font-semibold tracking-[0.3em] text-primary-foreground shadow-glow transition hover:scale-[1.02]">
          {t("home.openCatalog")}
        </Link>
      </div>
    </div>
  );
}

function StudyTimer({ todaySec }: { todaySec: number }) {
  const { t } = useI18n();
  const [sec, setSec] = useState(0);
  const [running, setRunning] = useState(false);
  const startedAt = useRef<string | null>(null);
  const save = useUpsert("study_sessions");
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSec((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [running]);
  function start() { if (!startedAt.current) startedAt.current = new Date().toISOString(); setRunning(true); }
  async function persist() {
    setRunning(false);
    if (sec < 1) return;
    await save.mutateAsync({ seconds: sec, started_at: startedAt.current ?? new Date().toISOString() });
    toast.success(t("common.saved"));
    setSec(0); startedAt.current = null;
  }
  const btn = "glass grid h-11 w-11 place-items-center rounded-full! transition hover:bg-accent";
  return (
    <section className="glass p-7 fade-up">
      <p className="motto text-muted-foreground">{t("home.timer")}</p>
      <p className="mt-4 font-display text-6xl font-semibold tabular-nums leading-none" dir="ltr">{fmtDuration(sec)}</p>
      <div className="mt-5 flex items-center gap-2">
        {running ? <button className={btn} onClick={() => setRunning(false)} aria-label={t("home.pause")}><Pause className="h-4 w-4" /></button>
          : <button className={btn} onClick={start} aria-label={t("home.start")}><Play className="h-4 w-4" /></button>}
        <button className={btn} onClick={() => { setRunning(false); setSec(0); startedAt.current = null; }} aria-label={t("home.reset")}><RotateCcw className="h-4 w-4" /></button>
        <button className={btn} onClick={persist} disabled={sec < 1} aria-label={t("home.save")}><Save className="h-4 w-4" /></button>
        <span className="ms-auto text-xs text-muted-foreground">{t("home.today")}: <span dir="ltr">{fmtDuration(todaySec + (running ? 0 : 0))}</span></span>
      </div>
    </section>
  );
}
