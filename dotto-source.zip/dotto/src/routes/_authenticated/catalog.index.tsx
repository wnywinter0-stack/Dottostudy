import { createFileRoute, Link } from "@tanstack/react-router";
import { Brain, FileText, ListVideo, PlayCircle, Plus, Trash2, Tv } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { useList, useRemove, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { youtubeParse } from "@/lib/progress";
import { PageHeader } from "@/components/AppShell";
import { SubjectSelect } from "@/components/SubjectSelect";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { NotesLibrary } from "./notes";
import { DocumentsLibrary } from "@/components/DocumentsLibrary";
import { AssistantChat } from "@/components/AssistantChat";

export const Route = createFileRoute("/_authenticated/catalog/")({
  head: () => ({ meta: [{ title: "Catalog — DOTTO" }, { name: "description", content: "Your personal learning workspace: videos, documents, AI and notes." }, { property: "og:title", content: "Catalog — DOTTO" }, { property: "og:description", content: "Your personal learning workspace: videos, documents, AI and notes." }] }),
  component: Catalog,
});

function Catalog() {
  const { t } = useI18n();
  const tab = "rounded-full px-4 py-2 text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground";
  return (
    <div className="mx-auto max-w-6xl">
      <PageHeader title={t("catalog.title")} />
      <Tabs defaultValue="videos">
        <TabsList className="glass mb-6 h-auto flex-wrap rounded-full! p-1.5">
          <TabsTrigger value="videos" className={tab}><PlayCircle className="me-2 h-4 w-4" />{t("catalog.videos")}</TabsTrigger>
          <TabsTrigger value="docs" className={tab}><FileText className="me-2 h-4 w-4" />{t("catalog.documents")}</TabsTrigger>
          <TabsTrigger value="ai" className={tab}><Brain className="me-2 h-4 w-4" />{t("catalog.ai")}</TabsTrigger>
          <TabsTrigger value="notes" className={tab}>{t("catalog.notes")}</TabsTrigger>
        </TabsList>
        <TabsContent value="videos"><VideoHub /></TabsContent>
        <TabsContent value="docs"><DocumentsLibrary /></TabsContent>
        <TabsContent value="ai"><AssistantChat /></TabsContent>
        <TabsContent value="notes"><NotesLibrary /></TabsContent>
      </Tabs>
    </div>
  );
}

function VideoHub() {
  const { t } = useI18n();
  const { data: videos = [] } = useList("videos");
  const { data: subjects = [] } = useList("subjects");
  const save = useUpsert("videos");
  const del = useRemove("videos");
  const [f, setF] = useState({ url: "", title: "", collection: "", subject_id: null as string | null });
  const [filter, setFilter] = useState<string>("all");
  async function add(e: FormEvent) {
    e.preventDefault();
    const p = youtubeParse(f.url);
    if (!p) return void toast.error(t("catalog.invalid"));
    await save.mutateAsync({ url: f.url.trim(), kind: p.kind, youtube_id: p.id, title: f.title || f.url, collection: f.collection || null, subject_id: f.subject_id });
    setF({ url: "", title: "", collection: f.collection, subject_id: f.subject_id });
  }
  const collections = [...new Set(videos.map((v) => v.collection).filter(Boolean))] as string[];
  const shown = videos.filter((v) => filter === "all" || v.collection === filter || v.subject_id === filter);
  const Icon = { video: PlayCircle, playlist: ListVideo, channel: Tv } as Record<string, typeof Tv>;
  return (
    <div className="space-y-6">
      <form onSubmit={add} className="glass grid gap-3 p-5 md:grid-cols-[2fr_1.4fr_1fr_1fr_auto]">
        <Input required placeholder={t("catalog.addVideo")} value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} />
        <Input placeholder={t("common.title")} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        <Input placeholder={t("catalog.collection")} value={f.collection} onChange={(e) => setF({ ...f, collection: e.target.value })} />
        <SubjectSelect value={f.subject_id} onChange={(v) => setF({ ...f, subject_id: v })} />
        <button className="flex items-center justify-center gap-1 rounded-xl bg-gradient-blush px-4 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" />{t("common.add")}</button>
      </form>
      {(collections.length > 0 || subjects.length > 0) && (
        <div className="flex flex-wrap gap-2 text-xs">
          {[{ id: "all", name: "All" }, ...collections.map((c) => ({ id: c, name: c })), ...subjects].map((c) => (
            <button key={c.id} onClick={() => setFilter(c.id)} className={`rounded-full px-3 py-1.5 ${filter === c.id ? "bg-primary text-primary-foreground" : "glass rounded-full!"}`}>{c.name}</button>
          ))}
        </div>
      )}
      {shown.length === 0 ? <p className="glass p-10 text-center text-muted-foreground">{t("catalog.videoEmpty")}</p> : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((v) => {
            const I = Icon[v.kind] ?? PlayCircle;
            const inner = (
              <>
                <div className="aspect-video overflow-hidden rounded-t-[inherit] bg-plum">
                  {v.kind === "video" && v.youtube_id ? <img src={`https://i.ytimg.com/vi/${v.youtube_id}/hqdefault.jpg`} alt="" className="h-full w-full object-cover" loading="lazy" />
                    : <div className="grid h-full place-items-center"><I className="h-10 w-10 text-blush" strokeWidth={1.2} /></div>}
                </div>
                <div className="p-4"><p className="line-clamp-2 text-sm">{v.title}</p><p className="mt-1 text-xs text-muted-foreground">{v.collection ?? v.kind}</p></div>
              </>
            );
            return (
              <div key={v.id} className="glass group relative overflow-hidden">
                {v.kind === "channel" ? <a href={v.url} target="_blank" rel="noreferrer">{inner}</a>
                  : <Link to="/catalog/video/$id" params={{ id: v.id }}>{inner}</Link>}
                <button onClick={() => del.mutate(v.id)} aria-label={t("common.delete")} className="absolute end-2 top-2 rounded-full bg-glass-strong p-2 opacity-0 transition group-hover:opacity-100"><Trash2 className="h-3.5 w-3.5" /></button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
