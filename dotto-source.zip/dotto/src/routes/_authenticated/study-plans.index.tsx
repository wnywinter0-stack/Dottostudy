import { createFileRoute, Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";
import { useState, type FormEvent } from "react";
import { useList, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { planProgress } from "@/lib/progress";
import { PageHeader } from "@/components/AppShell";
import { SubjectSelect } from "@/components/SubjectSelect";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Bar } from "./home";

export const Route = createFileRoute("/_authenticated/study-plans/")({
  head: () => ({ meta: [{ title: "Study plans — DOTTO" }, { name: "description", content: "Organise lessons into study plans." }, { property: "og:title", content: "Study plans — DOTTO" }, { property: "og:description", content: "Organise lessons into study plans." }] }),
  component: Plans,
});

function Plans() {
  const { t } = useI18n();
  const { data: plans = [] } = useList("study_plans");
  const { data: lessons = [] } = useList("lessons");
  const { data: subjects = [] } = useList("subjects");
  return (
    <div className="mx-auto max-w-5xl">
      <PageHeader title={t("plans.title")} action={<PlanDialog />} />
      {plans.length === 0 ? <p className="glass p-10 text-center text-muted-foreground">{t("plans.empty")}</p> : (
        <div className="grid gap-5 sm:grid-cols-2">
          {plans.map((p) => {
            const v = planProgress(p.id, lessons);
            return (
              <Link key={p.id} to="/study-plans/$id" params={{ id: p.id }} className="glass block p-6 transition hover:-translate-y-0.5">
                <p className="text-xs text-blush">{subjects.find((s) => s.id === p.subject_id)?.name}</p>
                <h2 className="mt-1 text-2xl">{p.title}</h2>
                {p.deadline && <p className="mt-1 text-xs text-muted-foreground">{t("plans.deadline")}: {p.deadline}</p>}
                <div className="mt-5 flex items-center gap-3"><div className="flex-1"><Bar value={v} /></div><span className="text-sm">{v}%</span></div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}

function PlanDialog() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "", description: "", exam_target: "", start_date: "", deadline: "", subject_id: null as string | null });
  const save = useUpsert("study_plans");
  async function submit(e: FormEvent) {
    e.preventDefault();
    await save.mutateAsync({ ...f, start_date: f.start_date || null, deadline: f.deadline || null });
    setOpen(false); setF({ title: "", description: "", exam_target: "", start_date: "", deadline: "", subject_id: null });
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger className="flex items-center gap-2 rounded-full bg-gradient-blush px-5 py-2.5 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" />{t("plans.new")}</DialogTrigger>
      <DialogContent className="glass-strong">
        <DialogHeader><DialogTitle className="font-display text-2xl">{t("plans.new")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <Input required placeholder={t("common.title")} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <SubjectSelect value={f.subject_id} onChange={(v) => setF({ ...f, subject_id: v })} />
          <Textarea placeholder={t("common.description")} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <Input placeholder={t("plans.examTarget")} value={f.exam_target} onChange={(e) => setF({ ...f, exam_target: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <label className="text-xs text-muted-foreground">{t("plans.start")}<Input type="date" value={f.start_date} onChange={(e) => setF({ ...f, start_date: e.target.value })} /></label>
            <label className="text-xs text-muted-foreground">{t("plans.deadline")}<Input type="date" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></label>
          </div>
          <button className="h-11 w-full rounded-xl bg-gradient-blush font-semibold text-primary-foreground">{t("common.save")}</button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
