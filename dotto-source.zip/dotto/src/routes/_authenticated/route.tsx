import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    if (localStorage.getItem("dotto-ephemeral") && !sessionStorage.getItem("dotto-alive")) {
      localStorage.removeItem("dotto-ephemeral");
      await supabase.auth.signOut();
    }
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
  },
  component: () => <AppShell><Outlet /></AppShell>,
});
