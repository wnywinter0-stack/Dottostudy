import { createFileRoute } from '@tanstack/react-router';
import { DocumentsLibrary } from '@/components/DocumentsLibrary';
import { PageHeader } from '@/components/AppShell';
import { useI18n } from '@/lib/i18n';
export const Route=createFileRoute('/_authenticated/documents')({head:()=>({meta:[{title:'Documents — DOTTO'},{name:'description',content:'Your private PDF library and intelligent study documents.'},{property:'og:title',content:'Documents — DOTTO'},{property:'og:description',content:'Your private PDF library and intelligent study documents.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),component:Documents});
function Documents(){const {t}=useI18n();return <div className="mx-auto max-w-6xl"><PageHeader title={t('catalog.documents')}/><DocumentsLibrary/></div>;}
