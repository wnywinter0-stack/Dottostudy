import { createFileRoute } from "@tanstack/react-router";
import { CalendarPlus, Pencil, Plus, Trash2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { type Row, useList, useRemove, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { PageHeader } from "@/components/AppShell";
import { SubjectSelect } from "@/components/SubjectSelect";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/tasks")({
  head: () => ({ meta: [{ title: "Tasks — DOTTO" }, { name: "description", content: "Plan and track your study tasks." }, { property: "og:title", content: "Tasks — DOTTO" }, { property: "og:description", content: "Plan and track your study tasks." }] }),
  component: Tasks,
});

type Task = Row<"tasks">;
function bucket(x: Task, now = new Date()) {
  if (x.completed) return "completed";
  if (!x.due_at) return "upcoming";
  const d = new Date(x.due_at);
  if (d < now) return "overdue";
  return d.toDateString() === now.toDateString() ? "today" : "upcoming";
}
function countdown(due: string, t: (k: "tasks.left" | "tasks.late") => string) {
  const ms = new Date(due).getTime() - Date.now();
  const h = Math.round(Math.abs(ms) / 3600000);
  const s = h >= 48 ? Math.round(h / 24) + "d" : h + "h";
  return ms >= 0 ? `${s} ${t("tasks.left")}` : `${s} ${t("tasks.late")}`;
}
function gcalLink(x: Task) {
  const start = new Date(x.due_at!); const end = new Date(start.getTime() + (x.estimated_minutes ?? 60) * 60000);
  const f = (d: Date) => d.toISOString().replace(/[-:]|\.\d{3}/g, "");
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(x.title)}&dates=${f(start)}/${f(end)}&details=${encodeURIComponent(x.description ?? "")}`;
}

function Tasks() {
  const { t } = useI18n();
  const { data: tasks = [] } = useList("tasks", "due_at", true);
  const save = useUpsert("tasks");
  const del = useRemove("tasks");
  const [edit, setEdit] = useState<Partial<Task> | null>(null);
  const groups = ["overdue", "today", "upcoming", "completed"] as const;
  const prColor = { high: "bg-blush", medium: "bg-mauve", low: "bg-muted" } as Record<string, string>;
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title={t("tasks.title")} action={
        <button onClick={() => setEdit({ priority: "medium" })} className="flex items-center gap-2 rounded-full bg-gradient-blush px-5 py-2.5 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" />{t("tasks.new")}</button>} />
      <div className="space-y-8">
        {groups.map((g) => {
          const items = tasks.filter((x) => bucket(x) === g);
          return (
            <section key={g}>
              <h2 className="mb-3 text-2xl">{t(`tasks.${g}`)} <span className="text-base text-muted-foreground">({items.length})</span></h2>
              {items.length === 0 ? <p className="text-sm text-muted-foreground">{t("tasks.empty")}</p> : (
                <ul className="space-y-2">
                  {items.map((x) => (
                    <li key={x.id} className="glass flex items-center gap-3 p-4">
                      <Checkbox checked={x.completed} onCheckedChange={(c) => save.mutate({ id: x.id, title: x.title, completed: !!c, completed_at: c ? new Date().toISOString() : null })} />
                      <span className={`h-2 w-2 shrink-0 rounded-full ${prColor[x.priority]}`} />
                      <div className="min-w-0 flex-1">
                        <p className={`truncate text-sm ${x.completed ? "line-through text-muted-foreground" : ""}`}>{x.title}</p>
                        <p className="text-xs text-muted-foreground">{x.due_at ? new Date(x.due_at).toLocaleString() + " · " + countdown(x.due_at, t) : ""}{x.estimated_minutes ? ` · ${x.estimated_minutes} min` : ""}</p>
                      </div>
                      {x.due_at && <a href={gcalLink(x)} target="_blank" rel="noreferrer" aria-label="Google Calendar" className="text-muted-foreground hover:text-foreground"><CalendarPlus className="h-4 w-4" /></a>}
                      <button onClick={() => setEdit(x)} aria-label={t("common.edit")} className="text-muted-foreground hover:text-foreground"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => del.mutate(x.id)} aria-label={t("common.delete")} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </div>
      {edit && <TaskDialog task={edit} onClose={() => setEdit(null)} />}
    </div>
  );
}

function toLocal(iso: string | null | undefined) {
  if (!iso) return "";
  const d = new Date(iso); d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 16);
}

function TaskDialog({ task, onClose }: { task: Partial<Task>; onClose: () => void }) {
  const { t } = useI18n();
  const save = useUpsert("tasks");
  const { data: plans = [] } = useList("study_plans");
  const [f, setF] = useState({ ...task, due_local: toLocal(task.due_at) });
  async function submit(e: FormEvent) {
    e.preventDefault();
    const { due_local, ...rest } = f;
    await save.mutateAsync({ ...(rest as Task), due_at: due_local ? new Date(due_local).toISOString() : null });
    onClose();
  }
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="glass-strong">
        <DialogHeader><DialogTitle className="font-display text-2xl">{task.id ? t("common.edit") : t("tasks.new")}</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <Input required placeholder={t("common.title")} value={f.title ?? ""} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <Textarea placeholder={t("common.description")} value={f.description ?? ""} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <SubjectSelect value={f.subject_id ?? null} onChange={(v) => setF({ ...f, subject_id: v })} />
          <select value={f.plan_id ?? ""} onChange={(e) => setF({ ...f, plan_id: e.target.value || null })} className="h-10 w-full rounded-xl border border-input bg-glass px-3 text-sm">
            <option value="" className="bg-popover">{t("nav.plans")}: {t("common.none")}</option>
            {plans.map((p) => <option key={p.id} value={p.id} className="bg-popover">{p.title}</option>)}
          </select>
          <div className="grid grid-cols-2 gap-3">
            <select value={f.priority ?? "medium"} onChange={(e) => setF({ ...f, priority: e.target.value })} className="h-10 rounded-xl border border-input bg-glass px-3 text-sm">
              {(["low", "medium", "high"] as const).map((p) => <option key={p} value={p} className="bg-popover">{t(`tasks.${p}`)}</option>)}
            </select>
            <Input type="number" min={0} placeholder={t("tasks.duration")} value={f.estimated_minutes ?? ""} onChange={(e) => setF({ ...f, estimated_minutes: e.target.value ? Number(e.target.value) : null })} />
          </div>
          <label className="block text-xs text-muted-foreground">{t("tasks.due")}<Input type="datetime-local" value={f.due_local} onChange={(e) => setF({ ...f, due_local: e.target.value })} /></label>
          <button className="h-11 w-full rounded-xl bg-gradient-blush font-semibold text-primary-foreground">{t("common.save")}</button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
