import { createFileRoute } from "@tanstack/react-router";
import { Plus, Search, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { useList, useRemove, useUpsert } from "@/lib/data";
import { useI18n } from "@/lib/i18n";
import { PageHeader } from "@/components/AppShell";
import { NoteEditor } from "@/components/NoteEditor";
import { SubjectSelect } from "@/components/SubjectSelect";

export const Route = createFileRoute("/_authenticated/notes")({
  head: () => ({ meta: [{ title: "My notes — DOTTO" }, { name: "description", content: "Your personal DOTTO notes library." }, { property: "og:title", content: "My notes — DOTTO" }, { property: "og:description", content: "Your personal DOTTO notes library." }] }),
  component: Notes,
});

export function NotesLibrary() {
  const { t } = useI18n();
  const { data: notes = [] } = useList("notes", "updated_at");
  const { data: subjects = [] } = useList("subjects");
  const { data: videos = [] } = useList("videos");
  const save = useUpsert("notes");
  const del = useRemove("notes");
  const [sel, setSel] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [sub, setSub] = useState<string | null>(null);
  const list = useMemo(() => notes.filter((n) => (!sub || n.subject_id === sub) && (n.title + n.content).toLowerCase().includes(q.toLowerCase())), [notes, q, sub]);
  const current = notes.find((n) => n.id === sel) ?? null;
  return (
    <div className="grid gap-5 lg:grid-cols-[300px_minmax(0,1fr)]">
      <aside className="glass space-y-3 p-4">
        <button onClick={async () => { const n = await save.mutateAsync({ title: t("notes.new"), subject_id: sub }); setSel(n.id); }}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-blush py-2.5 text-sm font-semibold text-primary-foreground"><Plus className="h-4 w-4" />{t("notes.new")}</button>
        <div className="relative"><Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("common.search")} className="h-10 w-full rounded-xl border border-input bg-glass ps-9 pe-3 text-sm outline-none" /></div>
        <SubjectSelect value={sub} onChange={setSub} />
        <ul className="max-h-[60vh] space-y-1 overflow-y-auto">
          {list.length === 0 && <li className="p-3 text-sm text-muted-foreground">{t("notes.empty")}</li>}
          {list.map((n) => (
            <li key={n.id}>
              <button onClick={() => setSel(n.id)} className={`w-full rounded-xl px-3 py-2 text-start ${sel === n.id ? "bg-accent" : "hover:bg-muted"}`}>
                <p className="truncate text-sm">{n.title}</p>
                <p className="truncate text-xs text-muted-foreground">{videos.find((v) => v.id === n.video_id)?.title ?? subjects.find((s) => s.id === n.subject_id)?.name ?? new Date(n.updated_at).toLocaleDateString()}</p>
              </button>
            </li>
          ))}
        </ul>
      </aside>
      <section className="glass min-h-[60vh] p-6">
        {current ? (
          <div className="flex h-full flex-col">
            <div className="mb-3 flex items-center gap-3">
              <div className="w-56"><SubjectSelect value={current.subject_id} onChange={(v) => save.mutate({ id: current.id, subject_id: v })} /></div>
              <button onClick={() => { del.mutate(current.id); setSel(null); }} className="ms-auto text-muted-foreground hover:text-destructive" aria-label={t("common.delete")}><Trash2 className="h-4 w-4" /></button>
            </div>
            <NoteEditor note={current} />
          </div>
        ) : <p className="grid h-full place-items-center text-muted-foreground">{t("notes.empty")}</p>}
      </section>
    </div>
  );
}

function Notes() {
  const { t } = useI18n();
  return <div className="mx-auto max-w-6xl"><PageHeader title={t("notes.title")} /><NotesLibrary /></div>;
}
