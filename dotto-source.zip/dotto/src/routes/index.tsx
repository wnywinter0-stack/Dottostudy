import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Brain, CalendarDays, FileText, PlayCircle, Sparkles } from "lucide-react";
import { BrandLockup } from "@/components/Brand";
import { LangSwitch } from "@/components/LangSwitch";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DOTTO — Your learning. Your world. Your future." },
      { name: "description", content: "DOTTO: the premium study workspace. Plans, tasks, video notes, PDF annotation and AI quizzes — one lifetime purchase." },
      { property: "og:title", content: "DOTTO — Learn • Organize • Achieve" },
      { property: "og:description", content: "A premium AI-powered learning workspace for students. Pay once, own it for life." },
    ],
  }),
  component: Landing,
});

function Landing() {
  const { t } = useI18n();
  const features = [
    { icon: BookOpen, label: t("nav.plans") }, { icon: PlayCircle, label: t("catalog.videos") },
    { icon: FileText, label: t("catalog.documents") }, { icon: Brain, label: t("catalog.ai") },
    { icon: CalendarDays, label: t("nav.calendar") }, { icon: Sparkles, label: t("nav.progress") },
  ];
  return (
    <div className="flex min-h-screen flex-col px-6 py-6">
      <div className="flex justify-end"><LangSwitch /></div>
      <section className="mx-auto flex max-w-3xl flex-1 flex-col items-center justify-center py-16 fade-up">
        <BrandLockup />
        <div className="mt-12 flex flex-wrap justify-center gap-3">
          <Link to="/auth" search={{ mode: "register" }} className="rounded-full bg-gradient-blush px-8 py-3 text-sm font-semibold text-primary-foreground shadow-glow">{t("auth.register")}</Link>
          <Link to="/auth" search={{ mode: "login" }} className="glass rounded-full! px-8 py-3 text-sm">{t("auth.login")}</Link>
        </div>
        <div className="mt-20 grid w-full grid-cols-2 gap-3 sm:grid-cols-3">
          {features.map(({ icon: Icon, label }) => (
            <div key={label} className="glass flex items-center gap-3 p-4 text-sm">
              <Icon className="h-5 w-5 shrink-0 text-blush" strokeWidth={1.4} /><span className="min-w-0">{label}</span>
            </div>
          ))}
        </div>
      </section>
      <footer className="flex justify-center gap-6 text-xs text-muted-foreground">
        <Link to="/terms">Terms</Link><Link to="/privacy">Privacy</Link><span>© DOTTO</span>
      </footer>
    </div>
  );
}
