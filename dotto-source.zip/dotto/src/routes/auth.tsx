import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { BrandLockup } from "@/components/Brand";
import { LangSwitch } from "@/components/LangSwitch";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useI18n } from "@/lib/i18n";

type Mode = "login" | "register" | "forgot";
export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { mode?: Mode | undefined } => {
    const m = s["mode"];
    return { mode: m === "register" || m === "forgot" || m === "login" ? m : undefined };
  },
  head: () => ({ meta: [
    { title: "Log in — DOTTO" }, { name: "description", content: "Log in or create your DOTTO account." },
    { property: "og:title", content: "Log in — DOTTO" }, { property: "og:description", content: "Your learning. Your world. Your future." },
  ] }),
  component: AuthPage,
});

const GoogleG = () => (
  <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"/><path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"/><path fill="#FBBC05" d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"/><path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"/></svg>
);

function AuthPage() {
  const { t } = useI18n();
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(search.mode ?? "login");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [remember, setRemember] = useState(true);
  const [accept, setAccept] = useState(false);
  const [f, setF] = useState({ name: "", email: "", password: "", confirm: "" });

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/home", replace: true }); });
  }, [navigate]);

  function markRemember() {
    if (remember) localStorage.removeItem("dotto-ephemeral");
    else { localStorage.setItem("dotto-ephemeral", "1"); sessionStorage.setItem("dotto-alive", "1"); }
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "login") {
        const { error } = await supabase.auth.signInWithPassword({ email: f.email, password: f.password });
        if (error) throw error;
        markRemember();
        navigate({ to: "/home" });
      } else if (mode === "register") {
        if (f.password !== f.confirm) throw new Error(t("auth.mismatch"));
        if (!accept) throw new Error(t("auth.mustAccept"));
        const { error } = await supabase.auth.signUp({
          email: f.email, password: f.password,
          options: { emailRedirectTo: window.location.origin + "/home", data: { full_name: f.name } },
        });
        if (error) throw error;
        toast.success(t("auth.checkEmail"));
        setMode("login");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(f.email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        toast.success(t("auth.resetSent"));
        setMode("login");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : t("common.error"));
    } finally { setBusy(false); }
  }

  async function google() {
    markRemember();
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) { toast.error(r.error.message ?? t("common.error")); return; }
    if (r.redirected) return;
    navigate({ to: "/home" });
  }

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const fieldCls = "h-12 rounded-xl bg-glass";

  return (
    <div className="flex min-h-screen flex-col px-4 py-6">
      <div className="flex justify-end"><LangSwitch /></div>
      <div className="flex flex-1 items-center justify-center py-8">
        <div className="w-full max-w-md fade-up">
          <BrandLockup />
          <form onSubmit={submit} className="glass-strong mt-10 space-y-4 p-7 sm:p-9">
            <h2 className="text-center text-2xl">{mode === "register" ? t("auth.join") : mode === "forgot" ? t("auth.forgot") : t("auth.welcome")}</h2>
            {mode === "register" && <Input required placeholder={t("auth.fullname")} value={f.name} onChange={set("name")} className={fieldCls} autoComplete="name" />}
            <Input required type="email" placeholder={t("auth.email")} value={f.email} onChange={set("email")} className={fieldCls} autoComplete="email" />
            {mode !== "forgot" && (
              <div className="relative">
                <Input required minLength={8} type={show ? "text" : "password"} placeholder={t("auth.password")} value={f.password} onChange={set("password")}
                  className={`${fieldCls} pe-12`} autoComplete={mode === "login" ? "current-password" : "new-password"} />
                <button type="button" onClick={() => setShow(!show)} aria-label="Toggle password" className="absolute inset-y-0 end-3 text-muted-foreground">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            )}
            {mode === "register" && <Input required type={show ? "text" : "password"} placeholder={t("auth.confirm")} value={f.confirm} onChange={set("confirm")} className={fieldCls} autoComplete="new-password" />}
            {mode === "login" && (
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-muted-foreground"><Checkbox checked={remember} onCheckedChange={(v) => setRemember(!!v)} />{t("auth.remember")}</label>
                <button type="button" onClick={() => setMode("forgot")} className="text-blush hover:underline">{t("auth.forgot")}</button>
              </div>
            )}
            {mode === "register" && (
              <label className="flex items-start gap-2 text-sm text-muted-foreground">
                <Checkbox checked={accept} onCheckedChange={(v) => setAccept(!!v)} className="mt-0.5" />
                <span>{t("auth.terms")} (<Link to="/terms" className="text-blush">Terms</Link> · <Link to="/privacy" className="text-blush">Privacy</Link>)</span>
              </label>
            )}
            <button disabled={busy} className="flex h-12 w-full items-center justify-center rounded-xl bg-gradient-blush font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
              {busy && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
              {mode === "login" ? t("auth.login") : mode === "register" ? t("auth.register") : t("auth.sendReset")}
            </button>
            {mode !== "forgot" && <>
              <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />{t("auth.or")}<span className="h-px flex-1 bg-border" /></div>
              <button type="button" onClick={google} className="btn-google flex h-12 w-full items-center justify-center gap-2.5 rounded-xl px-3">
                <GoogleG />{t("auth.google")}
              </button>
            </>}
            <p className="pt-2 text-center text-sm text-muted-foreground">
              {mode === "login" ? <>{t("auth.noAccount")} <button type="button" onClick={() => setMode("register")} className="text-blush">{t("auth.register")}</button></>
                : mode === "register" ? <>{t("auth.haveAccount")} <button type="button" onClick={() => setMode("login")} className="text-blush">{t("auth.login")}</button></>
                : <button type="button" onClick={() => setMode("login")} className="text-blush">{t("auth.back")}</button>}
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
