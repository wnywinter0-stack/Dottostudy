import { createFileRoute, Link } from "@tanstack/react-router";
import { Wordmark } from "@/components/Brand";

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [
    { title: "Privacy Policy — DOTTO" }, { name: "description", content: "DOTTO Privacy Policy." },
    { property: "og:title", content: "Privacy Policy — DOTTO" }, { property: "og:description", content: "DOTTO Privacy Policy." },
  ] }),
  component: () => (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <Link to="/"><Wordmark /></Link>
      <article className="glass mt-10 space-y-4 p-8 text-sm leading-relaxed text-muted-foreground">
        <h1 className="text-4xl text-foreground">Privacy Policy</h1>
        <p>This document is a placeholder that the DOTTO founder should replace with reviewed legal text before launch.</p>
        <p>Each student account is private. Your notes, documents, plans, tasks and progress are visible only to you. We never sell your data.</p>
      </article>
    </div>
  ),
});
