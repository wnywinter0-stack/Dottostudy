import { createFileRoute, Link } from "@tanstack/react-router";
import { Wordmark } from "@/components/Brand";

export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [
    { title: "Terms of Service — DOTTO" }, { name: "description", content: "DOTTO Terms of Service." },
    { property: "og:title", content: "Terms of Service — DOTTO" }, { property: "og:description", content: "DOTTO Terms of Service." },
  ] }),
  component: () => (
    <div className="mx-auto max-w-2xl px-6 py-16">
      <Link to="/"><Wordmark /></Link>
      <article className="glass mt-10 space-y-4 p-8 text-sm leading-relaxed text-muted-foreground">
        <h1 className="text-4xl text-foreground">Terms of Service</h1>
        <p>This document is a placeholder that the DOTTO founder should replace with reviewed legal text before launch.</p>
        <p>DOTTO is sold as a one-time purchase granting lifetime access to the purchased version. AI features are subject to fair-use limits.</p>
      </article>
    </div>
  ),
});
