import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { BrandLockup } from "@/components/Brand";
import { Input } from "@/components/ui/input";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "Reset password — DOTTO" }, { name: "description", content: "Choose a new DOTTO password." },
    { property: "og:title", content: "Reset password — DOTTO" }, { property: "og:description", content: "Choose a new DOTTO password." },
  ] }),
  component: Reset,
});

function Reset() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const [p, setP] = useState(""); const [c, setC] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (p !== c) return void toast.error(t("auth.mismatch"));
    const { error } = await supabase.auth.updateUser({ password: p });
    if (error) return void toast.error(error.message);
    toast.success(t("common.saved"));
    navigate({ to: "/home" });
  }
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md">
        <BrandLockup />
        <form onSubmit={submit} className="glass-strong mt-10 space-y-4 p-8">
          <h2 className="text-center text-2xl">{t("auth.newPassword")}</h2>
          <Input type="password" required minLength={8} placeholder={t("auth.newPassword")} value={p} onChange={(e) => setP(e.target.value)} className="h-12 rounded-xl" />
          <Input type="password" required minLength={8} placeholder={t("auth.confirm")} value={c} onChange={(e) => setC(e.target.value)} className="h-12 rounded-xl" />
          <button className="h-12 w-full rounded-xl bg-gradient-blush font-semibold text-primary-foreground">{t("auth.updatePassword")}</button>
        </form>
      </div>
    </div>
  );
}
