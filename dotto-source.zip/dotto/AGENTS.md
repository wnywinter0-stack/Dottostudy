<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules
- Student data tables carry `user_id default auth.uid()` with a single owner-only RLS policy; the browser client reads/writes them directly via `src/lib/data.ts` hooks. Why: RLS is the privacy boundary, so no per-table server functions are needed.
- All UI strings go through `useI18n().t` with keys in `src/lib/i18n-dict.ts` (en/fr/ar); Arabic sets `dir="rtl"`, so use logical utilities (ms/me/ps/pe/start/end). Why: full-app translation and RTL.
- PDF parsing and OCR are lazy browser-only modules; page-tagged sections persist privately with full-text retrieval. Why: keep heavyweight PDF/OCR code out of the server runtime.
- Assistant model calls run behind a verified bearer session on a streaming server route; saved messages are one continuous account-owned conversation and usage reservations are atomic. Why: secrets stay server-side and limits cannot be raced.
- Document-wide study actions reduce all extracted sections in bounded batches; question answering retrieves ranked sections or an explicit page. Why: large PDFs remain searchable without pretending retrieved excerpts cover the whole document.
