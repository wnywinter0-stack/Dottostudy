# DOTTO roadmap
- [x] Current request: real AI assistant with one continuous account-saved conversation; private PDF upload, extraction/OCR, retrieval, study tools, and desktop/mobile tests
- [x] Phase 1: design system, chrome background, EN/FR/AR + RTL, email + Google login, app shell, Home
- [x] Phase 2: subjects, study plans + lessons, tasks, notes (autosave), progress charts, study timer
- [x] Phase 3a: YouTube hub + split-screen notes with timestamps
- [ ] Phase 3b remaining: image uploads and real annotation editor (private PDF uploads and reading complete)
- [x] Phase 4: AI study assistant (summaries, quizzes, flashcards, history, fair-use limits)
- [ ] Phase 5: Google Calendar sync — needs a Google OAuth client from the founder
- [ ] Phase 6: one-time Stripe purchase, invitations, lifetime entitlements, admin panel — needs founder approval to enable payments
- [ ] Phase 7: polish, OWNERSHIP.md (licenses), end-to-end tests
